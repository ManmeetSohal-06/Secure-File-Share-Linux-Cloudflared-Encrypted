const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const db = require('../db');
const { authMiddleware } = require('./auth');

const router = express.Router();

const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, '..', 'uploads'),
    filename: (req, file, cb) => {
      cb(null, crypto.randomUUID());
    }
  }),
  limits: { fileSize: 200 * 1024 * 1024 }
});

router.post('/upload', authMiddleware, upload.single('encryptedFile'), (req, res) => {
  const { recipientUsername, filename, encryptedAesKey, ivFile, ivKey, ephemeralPublicKey, expiresInHours } = req.body;

  if (!req.file || !recipientUsername || !filename || !encryptedAesKey || !ivFile || !ivKey || !ephemeralPublicKey) {
    return res.status(400).json({ error: 'missing required fields' });
  }

  const recipient = db.prepare('SELECT id FROM users WHERE username = ?').get(recipientUsername);
  if (!recipient) {
    fs.unlinkSync(req.file.path);
    return res.status(404).json({ error: 'recipient not found' });
  }

  const expiresAt = expiresInHours
    ? new Date(Date.now() + Number(expiresInHours) * 3600 * 1000).toISOString()
    : null;

  const result = db.prepare(`
    INSERT INTO files
      (sender_id, recipient_id, filename, stored_path, encrypted_aes_key, iv_file, iv_key, ephemeral_public_key, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    req.user.id,
    recipient.id,
    filename,
    req.file.filename,
    encryptedAesKey,
    ivFile,
    ivKey,
    ephemeralPublicKey,
    expiresAt
  );

  res.json({ fileId: result.lastInsertRowid });
});

router.get('/received', authMiddleware, (req, res) => {
  const rows = db.prepare(`
    SELECT f.id, f.filename, f.created_at, f.expires_at, f.downloaded, u.username AS sender
    FROM files f
    JOIN users u ON u.id = f.sender_id
    WHERE f.recipient_id = ?
    ORDER BY f.created_at DESC
  `).all(req.user.id);

  res.json(rows);
});

router.get('/:id/meta', authMiddleware, (req, res) => {
  const file = db.prepare('SELECT * FROM files WHERE id = ? AND recipient_id = ?')
    .get(req.params.id, req.user.id);

  if (!file) return res.status(404).json({ error: 'file not found' });

  if (file.expires_at && new Date(file.expires_at) < new Date()) {
    return res.status(410).json({ error: 'file has expired' });
  }

  res.json({
    filename: file.filename,
    encryptedAesKey: file.encrypted_aes_key,
    ivFile: file.iv_file,
    ivKey: file.iv_key,
    ephemeralPublicKey: file.ephemeral_public_key
  });
});

router.get('/:id/download', authMiddleware, (req, res) => {
  const file = db.prepare('SELECT * FROM files WHERE id = ? AND recipient_id = ?')
    .get(req.params.id, req.user.id);

  if (!file) return res.status(404).json({ error: 'file not found' });

  if (file.expires_at && new Date(file.expires_at) < new Date()) {
    return res.status(410).json({ error: 'file has expired' });
  }

  const filePath = path.join(__dirname, '..', 'uploads', file.stored_path);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'file blob missing on server' });
  }

  db.prepare('UPDATE files SET downloaded = downloaded + 1 WHERE id = ?').run(file.id);

  res.sendFile(filePath);
});

module.exports = router;
