const express = require('express');
const db = require('../db');

const router = express.Router();

router.get('/:username/publickey', (req, res) => {
  const user = db.prepare('SELECT id, username, public_key FROM users WHERE username = ?')
    .get(req.params.username);

  if (!user) return res.status(404).json({ error: 'user not found' });

  res.json({ id: user.id, username: user.username, publicKey: user.public_key });
});

module.exports = router;
