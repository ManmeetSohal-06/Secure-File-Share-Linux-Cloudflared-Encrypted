const DB_NAME = 'secure-file-share-keys';
const STORE_NAME = 'keypairs';

function openKeyDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(STORE_NAME);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function storeKeyPair(username, keyPair) {
  const db = await openKeyDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(keyPair, username);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function loadKeyPair(username) {
  const db = await openKeyDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const req = tx.objectStore(STORE_NAME).get(username);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

function bufToBase64(buf) {
  return btoa(String.fromCharCode(...new Uint8Array(buf)));
}

function base64ToBuf(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

async function generateAndStoreKeyPair(username) {
  const keyPair = await crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveKey']
  );

  await storeKeyPair(username, keyPair);

  const rawPublic = await crypto.subtle.exportKey('spki', keyPair.publicKey);
  return bufToBase64(rawPublic);
}

async function importPublicKey(base64Key) {
  return crypto.subtle.importKey(
    'spki',
    base64ToBuf(base64Key),
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    []
  );
}

async function encryptFileForRecipient(fileArrayBuffer, recipientPublicKeyBase64) {
  const ephemeralKeyPair = await crypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveKey']
  );

  const recipientPublicKey = await importPublicKey(recipientPublicKeyBase64);

  const wrappingKey = await crypto.subtle.deriveKey(
    { name: 'ECDH', public: recipientPublicKey },
    ephemeralKeyPair.privateKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt']
  );

  const fileKey = await crypto.subtle.generateKey(
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt']
  );

  const ivFile = crypto.getRandomValues(new Uint8Array(12));
  const encryptedFile = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: ivFile },
    fileKey,
    fileArrayBuffer
  );

  const rawFileKey = await crypto.subtle.exportKey('raw', fileKey);
  const ivKey = crypto.getRandomValues(new Uint8Array(12));
  const encryptedAesKey = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: ivKey },
    wrappingKey,
    rawFileKey
  );

  const ephemeralPublicRaw = await crypto.subtle.exportKey('spki', ephemeralKeyPair.publicKey);

  return {
    encryptedFile: new Blob([encryptedFile]),
    encryptedAesKey: bufToBase64(encryptedAesKey),
    ivFile: bufToBase64(ivFile),
    ivKey: bufToBase64(ivKey),
    ephemeralPublicKey: bufToBase64(ephemeralPublicRaw)
  };
}

async function decryptFileFromSender(encryptedFileArrayBuffer, meta, recipientPrivateKey) {
  const ephemeralPublicKey = await importPublicKey(meta.ephemeralPublicKey);

  const wrappingKey = await crypto.subtle.deriveKey(
    { name: 'ECDH', public: ephemeralPublicKey },
    recipientPrivateKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt']
  );

  const rawFileKey = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: base64ToBuf(meta.ivKey) },
    wrappingKey,
    base64ToBuf(meta.encryptedAesKey)
  );

  const fileKey = await crypto.subtle.importKey(
    'raw',
    rawFileKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt']
  );

  const decryptedFile = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: base64ToBuf(meta.ivFile) },
    fileKey,
    encryptedFileArrayBuffer
  );

  return decryptedFile;
}
