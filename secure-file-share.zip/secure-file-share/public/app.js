let currentUser = null;
let authToken = null;

function setStatus(msg) {
  document.getElementById('status').textContent = msg;
}

document.getElementById('signupBtn').addEventListener('click', async () => {
  const username = document.getElementById('signupUsername').value;
  const password = document.getElementById('signupPassword').value;

  if (!username || !password) return setStatus('username and password required');

  setStatus('generating keypair...');
  const publicKey = await generateAndStoreKeyPair(username);

  const res = await fetch('/auth/signup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, publicKey })
  });

  const data = await res.json();
  if (!res.ok) return setStatus(`signup failed: ${data.error}`);

  authToken = data.token;
  currentUser = username;
  setStatus(`signed up and logged in as ${username}`);
  showApp();
});

document.getElementById('loginBtn').addEventListener('click', async () => {
  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;

  const res = await fetch('/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });

  const data = await res.json();
  if (!res.ok) return setStatus(`login failed: ${data.error}`);

  const keyPair = await loadKeyPair(username);
  if (!keyPair) return setStatus('no local private key found for this user on this browser/device');

  authToken = data.token;
  currentUser = username;
  setStatus(`logged in as ${username}`);
  showApp();
});

function showApp() {
  document.getElementById('authSection').style.display = 'none';
  document.getElementById('appSection').style.display = 'block';
  document.getElementById('whoami').textContent = currentUser;
  loadReceivedFiles();
}

document.getElementById('sendBtn').addEventListener('click', async () => {
  const recipientUsername = document.getElementById('recipientUsername').value;
  const fileInput = document.getElementById('fileInput');
  const expiresInHours = document.getElementById('expiresInHours').value;

  if (!fileInput.files.length) return setStatus('choose a file first');

  setStatus('fetching recipient public key...');
  const keyRes = await fetch(`/users/${recipientUsername}/publickey`);
  const keyData = await keyRes.json();
  if (!keyRes.ok) return setStatus(`could not find recipient: ${keyData.error}`);

  const file = fileInput.files[0];
  const fileBuffer = await file.arrayBuffer();

  setStatus('encrypting file in browser...');
  const encrypted = await encryptFileForRecipient(fileBuffer, keyData.publicKey);

  const formData = new FormData();
  formData.append('encryptedFile', encrypted.encryptedFile, 'blob');
  formData.append('recipientUsername', recipientUsername);
  formData.append('filename', file.name);
  formData.append('encryptedAesKey', encrypted.encryptedAesKey);
  formData.append('ivFile', encrypted.ivFile);
  formData.append('ivKey', encrypted.ivKey);
  formData.append('ephemeralPublicKey', encrypted.ephemeralPublicKey);
  if (expiresInHours) formData.append('expiresInHours', expiresInHours);

  setStatus('uploading encrypted file...');
  const uploadRes = await fetch('/files/upload', {
    method: 'POST',
    headers: { Authorization: `Bearer ${authToken}` },
    body: formData
  });

  const uploadData = await uploadRes.json();
  if (!uploadRes.ok) return setStatus(`upload failed: ${uploadData.error}`);

  setStatus(`file sent to ${recipientUsername}`);
});

async function loadReceivedFiles() {
  const res = await fetch('/files/received', {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  const files = await res.json();

  const list = document.getElementById('fileList');
  list.innerHTML = '';

  files.forEach((f) => {
    const li = document.createElement('li');
    li.textContent = `${f.filename} (from ${f.sender}) `;

    const btn = document.createElement('button');
    btn.textContent = 'Decrypt & Download';
    btn.addEventListener('click', () => downloadAndDecrypt(f.id, f.filename));

    li.appendChild(btn);
    list.appendChild(li);
  });
}

async function downloadAndDecrypt(fileId, filename) {
  setStatus('fetching metadata...');
  const metaRes = await fetch(`/files/${fileId}/meta`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  const meta = await metaRes.json();
  if (!metaRes.ok) return setStatus(`error: ${meta.error}`);

  setStatus('downloading encrypted blob...');
  const blobRes = await fetch(`/files/${fileId}/download`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  const encryptedBuffer = await blobRes.arrayBuffer();

  const keyPair = await loadKeyPair(currentUser);
  if (!keyPair) return setStatus('no local private key available to decrypt');

  setStatus('decrypting in browser...');
  const decryptedBuffer = await decryptFileFromSender(encryptedBuffer, meta, keyPair.privateKey);

  const blob = new Blob([decryptedBuffer]);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);

  setStatus(`decrypted and downloaded ${filename}`);
}

document.getElementById('refreshBtn').addEventListener('click', loadReceivedFiles);
