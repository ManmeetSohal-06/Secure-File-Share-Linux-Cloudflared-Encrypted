# Secure File Share — E2E Encrypted, Public-Key Exchange

## Architecture

Hybrid encryption (same pattern as PGP/ECIES):

1. Every user generates a long-term ECDH (P-256) keypair in the browser at signup. Only the **public key** goes to the server. The **private key** never leaves the browser — stored in IndexedDB.
2. To send a file, the sender's browser:
   - Generates a one-time **ephemeral ECDH keypair**
   - Derives a shared secret between the ephemeral private key and the recipient's public key
   - Uses that shared secret (as an AES-GCM key) to encrypt a randomly generated **file key**
   - Encrypts the actual file with that file key (AES-GCM)
   - Uploads: encrypted file blob, encrypted file key, IVs, and the ephemeral public key
3. To receive a file, the recipient's browser:
   - Uses their private key + the sender's ephemeral public key (stored alongside the file) to re-derive the same shared secret
   - Unwraps the file key, then decrypts the file

The server only ever stores ciphertext, encrypted keys, and public keys. It cannot decrypt anything — a genuine zero-knowledge server.

## Setup

```bash
cd secure-file-share
npm install
npm start
```

Server runs on `http://localhost:3000`. Open that URL in two different browsers (or two browser profiles) to simulate sender and recipient.

## Testing the flow

1. Sign up as `alice` in browser A
2. Sign up as `bob` in browser B
3. In browser A: send a file to `bob`
4. In browser B: click "Refresh" under Received Files, then "Decrypt & Download"

## Exposing it outside localhost (Cloudflare Tunnel)

```bash
cloudflared tunnel --url http://localhost:3000
```

This gives you a public HTTPS URL pointing at your local server — no port forwarding, no static IP needed.

## Known limitations (mention these in your report — they're expected for an MVP, not bugs)

- **No key recovery.** If a user clears browser storage or switches devices, their private key is gone and any files sent to them become permanently undecryptable. This is a deliberate trade-off of true E2E encryption.
- **No key verification (trust-on-first-use).** The server could theoretically serve a substituted public key (MITM). A production system would add key fingerprint verification, similar to Signal's "safety numbers." Out of scope for this MVP.
- **Single recipient only.** Multi-recipient sharing would require wrapping the file key separately per recipient's public key — straightforward extension, not implemented here.
- **No password-protected private key storage.** The private key sits in IndexedDB unencrypted-at-rest on the device. Anyone with access to the browser profile could extract it. A production version would derive an encryption key from a user passphrase to wrap the private key before storing it.

## File structure

```
secure-file-share/
├── server.js           Express app entry point
├── db.js                SQLite schema and connection
├── routes/
│   ├── auth.js           signup/login, JWT auth middleware
│   ├── users.js          public key lookup
│   └── files.js          upload/list/download encrypted files
├── public/
│   ├── index.html        UI
│   ├── crypto.js         Web Crypto API: keypair gen, hybrid encrypt/decrypt
│   └── app.js            wires UI to backend + crypto
├── uploads/               encrypted file blobs live here (gitignore this)
└── data/                  SQLite database file
```

## Suggested extension if time allows

Add a "safety number" comparison screen (hash of both users' public keys, shown as a short string) so users can manually verify they're talking to the right key out-of-band — directly addresses the MITM limitation above and is a strong talking point for a security report.
